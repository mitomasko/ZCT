# zct_AllPain

Web bezi na Heroku: https://starsrecognition.herokuapp.com/